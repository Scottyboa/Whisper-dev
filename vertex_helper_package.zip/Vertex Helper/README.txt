===========================================================
                Vertex Helper (Windows)
===========================================================

This folder contains the helper program needed to use the
"Gemini 3 (Vertex - GDPR friendly)" option in the web app.

You must run this helper on your computer while you use the app.
Nothing is uploaded or shared. Everything runs locally.


-----------------------------------------------------------
WHAT YOU MUST ADD (IMPORTANT)
-----------------------------------------------------------

You need to place your OWN Google Cloud "service_account.json"
file into this folder.

The app cannot work without this file.

How to get it:
1. Log into your Google Cloud Console.
2. Create a new Service Account (or use an existing one).
3. Go to its “Keys” section.
4. Click “Add Key → Create new key → JSON”.
5. Save the file and rename it to:

        service_account.json

6. Put it into THIS folder next to the .bat and .py files.


-----------------------------------------------------------
HOW TO RUN THE HELPER (WINDOWS)
-----------------------------------------------------------

1. Make sure this folder contains all 3 files:
       run_vertex_helper.bat
       vertex_auth_helper.py
       service_account.json   (you provide this)

2. Double-click:
       run_vertex_helper.bat

3. If Python is not installed on your computer:
   - You will get a message.
   - Press “Yes” to open the download page.
   - Install Python.
   - Then run the .bat file again.

4. If Python is installed:
   - The helper will automatically install what it needs.
   - Then it starts running.

5. When the helper is running you will see a message like:
       "Vertex Auth Helper running on http://127.0.0.1:9999"

   Leave the helper window open while you use the web app.


-----------------------------------------------------------
HOW TO USE THE APP
-----------------------------------------------------------

1. Start the helper (keep it open).
2. Open the web app in your browser.
3. Paste your own Google Cloud “Project ID” into the app.
4. Choose:
       "Gemini 3 (Vertex - GDPR friendly)"
5. Generate your notes as normal.


-----------------------------------------------------------
WHEN YOU ARE DONE
-----------------------------------------------------------

Simply close the helper window to stop it.


===========================================================
This helper runs only on your computer and never sends your
private key or data anywhere. You are always in control.
===========================================================
